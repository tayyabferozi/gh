(function () {
  window.onload = function () {
    // window.setTimeout(fadeout, 0);
  };
  function fadeout() {
    document.querySelector(".page-loader").style.opacity = "0";
    document.querySelector(".page-loader").style.display = "none";
  }
  window.onscroll = function () {
    var header_navbar = document.querySelector(".navbar-area");
    var sticky = header_navbar.offsetTop;
    if (window.pageYOffset > sticky) {
      header_navbar.classList.add("sticky");
    } else {
      header_navbar.classList.remove("sticky");
    }
    var backToTo = document.querySelector(".scroll-top");
    if (
      document.body.scrollTop > 50 ||
      document.documentElement.scrollTop > 50
    ) {
      backToTo.style.display = "flex";
    } else {
      backToTo.style.display = "none";
    }
  };

  //===== mobile-menu-btn
  let navbarToggler = document.querySelector(".navbar-toggler");
  navbarToggler.addEventListener("click", function () {
    navbarToggler.classList.toggle("active");
  });

  /**
   * client slider
   */
  new Swiper(".client-slider", {
    speed: 1900,
    loop: true,
    autoplay: {
      delay: 1000,
      disableOnInteraction: false,
    },
    slidesPerView: "auto",

    breakpoints: {
      320: {
        slidesPerView: 3,
        spaceBetween: 20,
      },

      576: {
        slidesPerView: 3,
        spaceBetween: 0,
      },

      768: {
        slidesPerView: 3,
        spaceBetween: 0,
      },

      992: {
        slidesPerView: 4,
        spaceBetween: 0,
      },

      1200: {
        slidesPerView: 5,
        spaceBetween: 0,
      },
    },
  });

  /**
   * workout slider
   */
  //  new Swiper('.workout-slider', {
  //   speed: 1000,
  //   loop: false,
  //   autoplay: {
  //     delay: 1000,
  //     disableOnInteraction: false
  //   },
  //   slidesPerView: 'auto',

  //   breakpoints: {
  //     320: {
  //       slidesPerView: 1,
  //       spaceBetween: 20
  //     },

  //     576: {
  //       slidesPerView: 2,
  //       spaceBetween: 5
  //     },

  //     768: {
  //       slidesPerView: 2,
  //       spaceBetween: 10
  //     },

  //     992: {
  //       slidesPerView: 3,
  //       spaceBetween: 10
  //     },

  //     1200: {
  //       slidesPerView: 3,
  //       spaceBetween: 15
  //     }
  //   }
  // });

  /**
   * trainer-slider
   */
  new Swiper(".trainer-slider", {
    speed: 1000,
    loop: false,
    autoplay: {
      delay: 1000,
      disableOnInteraction: false,
    },
    slidesPerView: "auto",

    breakpoints: {
      320: {
        slidesPerView: 1,
        spaceBetween: 20,
      },

      576: {
        slidesPerView: 2,
        spaceBetween: 5,
      },

      768: {
        slidesPerView: 2,
        spaceBetween: 10,
      },

      992: {
        slidesPerView: 3,
        spaceBetween: 10,
      },

      1200: {
        slidesPerView: 3,
        spaceBetween: 15,
      },
    },
  });

  const wrapScrollEl = document.querySelector(".scroll-text-wrap");
  const mainScrollEl = document.querySelector(".scroll-text");
  const navBarEl = document.querySelector(".navbar-area");
  const stepsCount = 7;
  let currStepNum = 1;

  const paintItems = () => {
    const allSpanEls = document.querySelectorAll(".scroll-text h2 span");

    if (allSpanEls) {
      allSpanEls.forEach((el, idx) => {
        el.classList.remove("painted");
        if (idx + 1 === currStepNum) {
          el.classList.add("painted");
        }
      });
    }
  };

  paintItems();

  const changeSections = () => {
    const vh = Math.max(
      document.documentElement.clientHeight || 0,
      window.innerHeight || 0
    );
    const navBarHeight = navBarEl.getBoundingClientRect().height;
    const top = window.pageYOffset + wrapScrollEl.getBoundingClientRect().top;
    const scrolledAfterEl = window.pageYOffset - top;
    const mainElHeight = mainScrollEl.getBoundingClientRect().height;
    const parentHeight = stepsCount * 1000 + mainElHeight;
    wrapScrollEl.style.height = `${parentHeight}px`;
    const usableHeight = parentHeight;

    if (window.screen.height <= mainElHeight + navBarHeight) {
      mainScrollEl.style.top = navBarHeight + "px";
    } else {
      mainScrollEl.style.top =
        vh / 2 - mainElHeight / 2 + navBarHeight / 2 + "px";
    }

    if (scrolledAfterEl > 0 && scrolledAfterEl < usableHeight) {
      const currStep = Math.ceil(scrolledAfterEl / (usableHeight / stepsCount));

      if (currStep !== currStepNum) {
        currStepNum = currStep;

        paintItems();
      }
    }
  };

  if (wrapScrollEl && mainScrollEl) {
    document.addEventListener("scroll", changeSections);
  }
})();
